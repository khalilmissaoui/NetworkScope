package tn.esprit.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import tn.esprit.demo.entity.EmbededKey;
import tn.esprit.demo.entity.Timesheet;

public interface TimesheetRepository extends JpaRepository<Timesheet, EmbededKey> {

}
