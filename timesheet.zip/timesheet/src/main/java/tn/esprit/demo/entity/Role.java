
package tn.esprit.demo.entity;

public enum Role {

	chefDepartement,administrateur,ingenieur
}
