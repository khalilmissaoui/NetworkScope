package tn.esprit.demo;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TimesheetApplicationTests {

	@Test
	void contextLoads() {
	}

}
